
var word = "";
var montoSoles  = 0;
var cuotas  = 0;
var montoCuota  = 0;
var logo ="<img src='logo.png'/>";

document.getElementById("btnCertificado").onclick = 
function () {
    CreateExcelFile();
    guardarImagenFichero();
    var blob = new Blob([word], { type: 'application/vnd.ms-word' });
    if (navigator.appVersion.toString().indexOf('.NET') > 0) {
        window.navigator.msSaveBlob(blob, "formatoPerson.doc");
    }else {
        this.download = "formatoPersona.doc";
        this.href = window.URL.createObjectURL(blob);
    }

}

function CreateExcelFile() {
    word = "<html><head><meta charset='UTF-8'></meta>";
    word += "</head><body>";
 	word += "<div style='font-size: 48pt;font-family:Bell MT'><center> CERTIFICADO</center><br></div>";
    word += "<div><center><img src='logo.png'></center><br><br></div>";   
    word += "<div style='font-family: Baskerville Old Face;font-size: 20pt'; margin: 10px;><center><b>ACLARA:</b></center><br><br></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 16pt; margin: 10px; text-align: justify;'><center>Que el contrato Nº____"
         + document.getElementById("numero") 
         +"____ a nombre del Sr. ____" 
         + document.getElementById("nombre") 
         + "____ Identificado con DNI. ____"
         + document.getElementById("dni") 
         + "____ podrá hacer uso de los beneficios de su membresía una vez cancelado el valor de la cuota inicial del total de la misma que corresponde al ____"
         + document.getElementById("porcentaje") 
         +"___% </center><br><br></div>";
   	word += "<div style='font-family: Calibri (Cuerpo);font-size: 11pt'><center><b>AUTORIZADO POR:</b></center><br><br></div>";

    word += "</body></html>";    
}


 document.getElementById("btnCalcular").onclick = function () {
	montoSoles = parseInt(document.getElementById("txtMontoSoles").value.toString());
	cuotas = parseInt(document.getElementById("txtCuotas").value.toString());
	montoCuota = montoSoles / cuotas;
	document.getElementById("txtMontoCuotas").value = montoCuota.toString();
}

function guardarImagenFichero (img) { 
    if (typeof img == 'object') 
    img = img.src; 
    window.newW = open (img); 
    newW.document.execCommand("SaveAs"); 
    newW.close(); 
} 