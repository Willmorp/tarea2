
	var word = "";
	var montoSoles  = 0;
	var cuotas  = 0;
	var montoCuota  = 0;
    var logo ="<img src='logo.png'/>";
   document.getElementById("btnPagare").onclick = function () {
        CreateExcelFile();
    
        var blob = new Blob([word], { type: 'application/vnd.ms-word' });
        if (navigator.appVersion.toString().indexOf('.NET') > 0) {
            window.navigator.msSaveBlob(blob, "formatoPerson.doc");
        } else {
            this.download = "formatoPersona.doc";
            this.href = window.URL.createObjectURL(blob);
        }

    }

    function CreateExcelFile() {
   
    word = "<html><head><meta charset='UTF-8'></meta>";
    word += "</head><body>";
 	word += "<div style='font-size: 12pt;font-family:Calibri(Cuerpo)'><center><b> PAGARÉ N°__" 
 		 + document.getElementById("numeroDoc")  
 		 +"___</b></center><br></div>";
 	word += "<div style='font-size: 10pt;font-family:Calibri(Cuerpo)'><center><b> POR UN VALOR DE (__" 
 		 + document.getElementById("valor") 
 		 +"soles)</b></center><br></div>";

  word += "<div style='font-size: 10pt;font-family:Calibri(Cuerpo)'><center>(S/.___" 
     + document.getElementById("valorSolesNumero") 
     +"  ____) ESTE VALOR ES EL SALDO A FINANCIAR</center><br></div>";

   	word += "<div style='font-size: 10pt;font-family:Calibri(Cuerpo)'><center> Yo____" 
   		 + document.getElementById("nombre") 
   		 + "______identificado(a) con DNI Nº___"
   		 + document.getElementById("dni")  
   		 +"___ con domicilio y residencia en "
       + document.getElementById("domicilio ")  
       +" </center></div>";  
   	word += "<div style='font-size: 10pt;font-family:Calibri(Cuerpo)'><center> Me comprometo a pagar incondicionalmente a VALLE ENCANTADO S.A.C la suma de ___" 
 		 + document.getElementById("montoSolesTexto")  
 		 +"SOLES (S/__" 
 		 + document.getElementById("montoSolesNumero")  
 		 + ") pagadero en "
 		 + document.getElementById("cuotas") 
 		 +" cuotas mensuales y consecutivas con vencimiento la primera de ella el día "
 		 + document.getElementById("diaPrimerCuota") 
 		 +" de "
 		 + document.getElementById("mesPrimerCuota") 
 		 +" del "
 		 + document.getElementById("anioPrimerCuota") 
 		 +" , por valor de (S/. "
 		 + document.getElementById("montoSolesNumero") 
 		 +" ). El pago de dichas cuotas se realizará en Soles a razón del cambio oficial vigente a la fecha en que se efectúe éste. En caso de mora y mientras ella subsista pagaré intereses moratorios a la tasa máxima establecida para el periodo correspondiente. De igual manera me obligo a pagar todos los gastos y costos de la cobranza judicial.   </center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>En el evento en que el deudor no pague en el plazo estipulado una o más cuotas, el tenedor de este título podrá declarar vencidos todos los plazos de esta obligación y pedir su inmediato pago total o el pago del saldo.</b></center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center> También acepto que VALLE ENCANTADO S.A.C, declare de plazo vencido la obligación a la que se refiere este pagaré y exigir su pago total en el evento en que sea perseguido judicialmente. El recibo de abono de parciales no implica novación y cualquier pago que se efectúe se imputará primero a gastos, penalidades, y por último a capital. El suscriptor de este pagaré hace constatar que la obligación de pagarla indivisiblemente y solidariamente subsiste en caso de prórroga o prórrogas o de cualquier modificación a lo estipulado. El deudor declara que la suma que debe conforme a este pagaré, no estará sujeta ni a deducción ni a descuentos de cualquier naturaleza, incluyendo sin limitación cualquier impuesto que pueda gravar su pago, por lo tanto, en caso de existir alguna de estas deducciones o descuentos, el deudor deberá aumentar la suma a pagar de tal manera que el tenedor reciba siempre el valor estipulado del pagaré. El deudor acepta desde ahora el endoso, cesión o transferencia que de este pagaré a VALLE ENCANTADO S.A.C. todos los gastos e impuestos relacionados con la suscripción de este pagaré serán por cuenta del deudor. </center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center> Todos los pagos que deban hacerse según este pagaré serán hechos exclusivamente en Soles, a la Cuenta Recaudadora Soles BCP N°193-2361209-0-94, en su oficina central ubicada en Av. Guardia Civil 1321 oficina 602 – Surquillo o en Ribera del Río Club Resort ubicada en Mz. B Lt. 72. Tercera Etapa - Cieneguilla. </center></div>";

    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Todos los cálculos de intereses se efectuarán sobre la base de un año de trescientos sesenta (360) días, en cada caso por el número de días efectivamente transcurridos (incluyendo el primer día, pero excluyendo el último día) durante el pazo por el cual deban pagarse tale intereses. Si cualquiera de las fechas de pago de principal o intereses antes indicadas coincidiera con un día no hábil, se entenderá que el pago respectivo deberá ser efectuado el día hábil inmediatamente siguiente.</center></div>";

   	word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Cualquier referencia en este pagaré al agente deberá entenderse efectuada a cualquier tenedor del mismo, sea que lo adquiera por endoso o de otro modo.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>En caso de mora, no será necesario requerimiento alguno para que el Cliente incurra en la misma, de acuerdo a lo establecido en el artículo 1333 inciso 1 del Código Civil Peruano. En dicho caso, durante todo el periodo de incumplimiento el cliente pagara a una tasa equivalente al máximo de interés permitido por la ley, por concepto de interés moratorio.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>De conformidad con lo establecido por el artículo 158.2 concordante con el artículo 52° de la Ley de Títulos Valores, este pagaré no requerirá ser protestado por la falta de pago de cualquiera de las cuotas para ejercitar las acciones derivadas del mismo.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Adicionalmente, el cliente se obliga incondicionalmente a pagar al Agente todos los gastos en que éste incurra en razón de su incumplimiento, obligándose a pagar sobre éstos el mismo interés moratorio pactado en este pagaré.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Asimismo, el cliente acepta las renovaciones y prórrogas de vencimiento de este pagaré que el agente considere conveniente efectuar, ya sea por su importe parcial o total, aun cuando no hayan sido comunicadas al cliente. Dichas modificaciones serán anotadas en este mismo instrumento o en hoja anexa, sin que sea necesaria la suscripción de tal instrumento.</b></center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Este pagare se devolverá a su cancelación total. Queda expresamente establecido que el domicilio del cliente es "
         + document.getElementById("domicilio") 
         + " Lima Perú, lugar a donde se dirigirán todas las comunicaciones y notificaciones derivadas de este pagaré. </center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Queda establecido que las obligaciones contenidas en este pagaré, constituyendo el presente acuerdo pacto en contrario a lo dispuesto por el artículo 1233° del Código Civil.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Este pagaré se regirá bajo las leyes de la República del Perú.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>Cualquier acción o procedimiento legal relacionado con y derivado del presente pagaré podrá ser iniciado ante los órganos judiciales del Cercado de Lima, Lima, Perú. El cliente renuncia a la jurisdicción de cualquier otro tribunal que pudiere corresponderle por cualquier otra razón.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>En constancia de lo anterior, se firma el presente pagaré el día "
    + document.getElementById("dia") 
    +" de  "
    + document.getElementById("mes") 
    +" del " 
    + document.getElementById("anio") 
    +" en la ciudad de Lima, </center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>El Deudor.</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>______________________________</b></center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>FIRMA</center></div>";
    word += "<div style='font-family: Calibri (Cuerpo);font-size: 10pt'><center>DNI N°</b></center></div>";

    word += "</body></html>";
    
}


 document.getElementById("btnCalcular").onclick = function () {
	montoSoles = parseInt(document.getElementById("txtMontoSoles").value.toString());
	cuotas = parseInt(document.getElementById("txtCuotas").value.toString());
	montoCuota = montoSoles / cuotas;
	document.getElementById("txtMontoCuotas").value = montoCuota.toString();
}

